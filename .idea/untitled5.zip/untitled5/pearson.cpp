//
// Created by Asus on 5/19/2023.
//

#include "pearson.h"

pearson::pearson(string n, int a) {
    name=n;
    age=a;



}

void pearson::printinfo() {
    cout << "Name: " << name << endl;
    cout << "Age: " << age << endl;

}
