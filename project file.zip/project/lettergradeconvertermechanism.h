//
// Created by Asus on 4/30/2023.
//
//polymorphis from grade class
#ifndef UNTITLED_IML_LETTERGRADECONVERTERMECHANISM_H
#define UNTITLED_IML_LETTERGRADECONVERTERMECHANISM_H
#include "grade.h"

class lettergradeconvertermechanism : public grade{
public:
    string getLetterGrade(int score);

};


#endif //UNTITLED_IML_LETTERGRADECONVERTERMECHANISM_H
