#include <iostream>
using namespace std;
#include "string"
#include "student.h"
#include "grade.h"
#include "course.h"
#include "cmake-build-debug/semester.h"
#include "quarter.h"
#include "honorstudent.h"
#include "lettergradeconvertermechanism.h"

int main() {
    const int numstudents = 50;
    student students[numstudents];
    cout << "welcome to our school system";
    cout << "we will start with taking your informations";
    cout << "we are now will get the information of each student now";
    for (int i = 0; i < numstudents; i++) {
        students[i].setname("student" + to_string(i + 1));
        students[i].getname();
        students[i].getage();
        students[i].getmajor();
        students[i].getgpa();
        students[i].printinformation();
    }
}

//
//    student student1("John Doe", 20, "Computer Science", 3.8);
//    student1.printinformation();
//    cout << "Does " << student1.getname() << " have honors? " << (student1.highgpa() ? "Yes" : "No") << endl;
//    student1.setgpa(3.2);
//    student1.printinformation();
//
//    grade englishgrade("english", 85, 100);
//    englishgrade.printinfo();
//
//
//    course cs101("Introduction to Computer Science", 101);
//    cs101.addstudents("John Doe");
//    cs101.addstudents("Jane Smith");
//    cs101.printstudents();
//
//    cs101.removestudent("John Doe");
//    cs101.printstudents();

//    semester fall2023("fall", 2023);
//    fall2023.addSubject("Math");
//    fall2023.addSubject("English");
//
//    fall2023.setGrade("Math", 85);
//    fall2023.setGrade("English", 92);
//
//    cout << "GPA for " << fall2023.getname() << " " << fall2023.getyear() << ": " << fall2023.getGPA() << endl;
//
//    fall2023.removeSubject("Math");
//
//    cout << "GPA for " << fall2023.getname() << " " << fall2023.getyear() << ": " << fall2023.getGPA() << endl;
//
//    semester fall2022("Fall", 2022);
//    fall2022.addSubject("Math");
//    fall2022.addSubject("English");
//
//    fall2022.setGrade("Math", 85);
//    fall2022.setGrade("English", 92);
//
//    cout << "Semester GPA for " << fall2022.getname() << " " << fall2022.getyear() << ": " << fall2022.getGPA() << endl;
//
//    quarter winter2023("Winter", 2023);
//    winter2023.addSubject("History");
//    winter2023.addSubject("Chemistry");
//
//    winter2023.setGrade("History", 90);
//    winter2023.setGrade("Chemistry", 87);
//
//    semester *currentSemester = &winter2023;
//    cout << "Semester GPA for " << currentSemester->getname() << " " << currentSemester->getyear() << ": "
//         << currentSemester->getGPA() << endl;
//
//    student student1("John Doe", 20, "Computer Science", 3.8);
//    student1.printinformation();
//    cout << "Does " << student1.getname() << " have honors? " << (student1.highgpa() ? "Yes" : "No") << endl;
//
//    honorstudent student4("Jane Smith", 22, "Engineering", 3.8);
//    student4.printinformation();
//    cout << "Does " << student4.getname() << " have honors? " << (student4.highgpa() ? "Yes" : "No") << endl;
//
//    student *currentStudent = &student4;
//    currentStudent->printinformation();
//    cout << "Does " << currentStudent->getname() << " have honors? " << (currentStudent->highgpa() ? "Yes" : "No")
//         <<endl;