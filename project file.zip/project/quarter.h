//
// Created by Asus on 4/29/2023.
//

#ifndef UNTITLED_IML_QUARTER_H
#define UNTITLED_IML_QUARTER_H
#include <iostream>
#include "string"
#include "student.h"
#include "grade.h"
#include "course.h"
#include "cmake-build-debug/semester.h"
//polymorphism
class quarter: public virtual semester {
public:
    quarter(string n, int y);
    double getGPA();

};


#endif //UNTITLED_IML_QUARTER_H
