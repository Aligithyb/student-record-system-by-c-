//
// Created by Asus on 4/29/2023.
//

#include "quarter.h"
quarter::quarter(string n, int y) : semester(n, y){

}

double quarter::getGPA() {
    double totalGradePoints = 0;
    int totalCredits = 0;
    for (int i = 0; i < getsubjects().size(); i++) {
        int grade = getgrades()[i];
        if (grade >= 0 && grade <= 100) {
            int credits = 4; // Assume all subjects are 4 credits
            totalGradePoints += grade * credits;
            totalCredits += credits;
        }
    }
    if (totalCredits == 0) {
        return 0;
    } else {
        return totalGradePoints / (totalCredits * 1.0);
    }
}


